from tkinter import *
from tkinter import messagebox
from PIL import ImageTk

def login() :
    if usernameEntry.get() == '' or passwordEntry.get() == '':
        messagebox.showerror('Error', 'Fields cannot be empty')
    elif usernameEntry.get()=='Admin' and passwordEntry.get()=='123456':
        messagebox.showinfo('Success','Welcome Admin')
        window.destroy()
        import Interface
    else:
        messagebox.showerror('Invalid', 'Please check credentials')


window = Tk()

window.geometry('1280x700+0+0')
window.title('Login to Student Management System')
window.resizable(False, False)
# importing image as background
backgroundImage = ImageTk.PhotoImage(file='bg.jpg')

bgLabel = Label(window, image=backgroundImage)
bgLabel.place(x=0, y=0)

loginFrame = Frame(window, bg='white')
loginFrame.place(x=430, y=250)

logoImage = PhotoImage(file='logo.png')
logoLabel = Label(loginFrame, image=logoImage, bg='white')
logoLabel.grid(row=0, column=0, columnspan=2, pady=10)

#Username field
usernameImage = PhotoImage(file='user.png')
usernameLabel = Label(loginFrame, image=usernameImage, text='Username', compound=LEFT, font=('times new roman',20,'bold'),
                      bg='white')
usernameLabel.grid(row=1, column=0, pady=10, padx=10)
usernameEntry = Entry(loginFrame, font=('Cambria',12,'bold'), bd=5, fg='royalblue')
usernameEntry.grid(row=1,column=1, pady=10, padx=10)

#Password field
passwordImage = PhotoImage(file='padlock.png')
passwordLabel = Label(loginFrame, image=passwordImage, text='Password', compound=LEFT, font=('times new roman',20,'bold'),
                      bg='white')
passwordLabel.grid(row=2, column=0, pady=10, padx=10)
passwordEntry = Entry(loginFrame, font=('Cambria',12,'bold'), bd=5, fg='royalblue')
passwordEntry.grid(row=2,column=1, pady=10, padx=10)

# Submit Button
loginButton = Button(loginFrame, text='Login', font=('Cambria',16,'bold'), width=8, fg='white', bg='cornflowerblue',
                     cursor='hand2', command=login)
loginButton.grid(row=3, column=0, columnspan=2, pady=10)


window.mainloop()
