from tkinter import *
import time
import ttkthemes
from tkinter import ttk, messagebox
import pymysql
# functions
def clock():
    date=time.strftime('%d/%m/%Y')
    currentTime=time.strftime('%H:%M:%S')
    datetimeLabel.config(text=f'     Date:{date} \nTime:{currentTime}')
    datetimeLabel.after(1000, clock)

def connect_database():
    def connect():
        try:
            con = pymysql.connect(host=hostEntry.get(), user=usernameEntry.get(), password=passwordEntry.get())
            mycursor = con.cursor()
        except:
            messagebox.showerror('Error','Invalid Details', parent=connectWindow)
            return
        try:
            query = 'create database studentmgmtsys'
            mycursor.execute(query)
            query = 'use studentmgmtsys'
            mycursor.execute(query)
            query = 'create table student(roll int primary key, name varchar(50) not null,course varchar(50) not null, ' \
                    'mob int not null, email varchar(30) not null, address varchar(50) not null, gender varchar(6) not null, ' \
                    'dob varchar(20) not null, doj varchar(20) not null)'
            mycursor.execute(query)
        except:
            query = 'use studentmgmtsys'
            mycursor.execute(query)
        messagebox.showinfo('Success', 'Database connected successfully', parent=connectWindow)
        connectWindow.destroy()
        addStu.config(state=NORMAL)
        searchStu.config(state=NORMAL)
        updateStu.config(state=NORMAL)
        deleteStu.config(state=NORMAL)
        showStu.config(state=NORMAL)
        exportStu.config(state=NORMAL)

    connectWindow = Toplevel()
    connectWindow.grab_set()
    connectWindow.geometry('400x240+530+230')
    connectWindow.title('Database Connection')
    connectWindow.resizable(False, False)

    hostnameLabel = Label(connectWindow, text='Host Name', font=('arial',15,'bold'))
    hostnameLabel.grid(row=0, column=0, padx=20)
    hostEntry = Entry(connectWindow, font=('roman', 13, 'bold'), bd=2)
    hostEntry.grid(row=0, column=1, padx=40, pady=20)

    usernameLabel = Label(connectWindow, text='UserName', font=('arial', 15, 'bold'))
    usernameLabel.grid(row=1, column=0, padx=20)
    usernameEntry = Entry(connectWindow, font=('roman', 13, 'bold'), bd=2)
    usernameEntry.grid(row=1, column=1, padx=40, pady=20)

    passwordLabel = Label(connectWindow, text='Password', font=('arial', 15, 'bold'))
    passwordLabel.grid(row=2, column=0, padx=20)
    passwordEntry = Entry(connectWindow, font=('roman', 13, 'bold'), bd=2)
    passwordEntry.grid(row=2, column=1, padx=40, pady=20)

    connectButton = ttk.Button(connectWindow, text='Connect', command=connect)
    connectButton.grid(row=3, column=0,columnspan=2)


# GUI
root=ttkthemes.ThemedTk()

root.get_themes()
root.set_theme('radiance')

root.geometry('1174x680+0+0')
root.title('Student Management System')
# root.resizable(False, False)

datetimeLabel=Label(root, text='hello', font=('Cambria', 12, 'bold'))
datetimeLabel.place(x=5, y=5)
clock()

s='Student Management System'
sliderLabel=Label(root, text=s, font=('Cambria', 28, 'bold'), width=30)
sliderLabel.place(x=270, y=0)

connectButton = ttk.Button(root, text='Connect Database', command=connect_database)
connectButton.place(x=980, y=0)


leftFrame = Frame(root)
leftFrame.place(x=30, y=65, width=300,height=600)

logo_Image=PhotoImage(file='student.png')
logo_Label=Label(leftFrame, image=logo_Image)
logo_Label.grid(row=0, column=0)

addStu = ttk.Button(leftFrame, text='Add Student', width=20, state=DISABLED)
addStu.grid(row=1, column=0, pady=20)

searchStu = ttk.Button(leftFrame, text='Search Student', width=20, state=DISABLED)
searchStu.grid(row=2, column=0, pady=20)

updateStu = ttk.Button(leftFrame, text='Update Student', width=20, state=DISABLED)
updateStu.grid(row=3, column=0, pady=20)

deleteStu = ttk.Button(leftFrame, text='Delete Student', width=20, state=DISABLED)
deleteStu.grid(row=4, column=0, pady=20)

showStu = ttk.Button(leftFrame, text='Show Student', width=20, state=DISABLED)
showStu.grid(row=5, column=0, pady=20)

exportStu = ttk.Button(leftFrame, text='Export Data', width=20, state=DISABLED)
exportStu.grid(row=6, column=0, pady=20)

exitStu = ttk.Button(leftFrame, text='Exit', width=20)
exitStu.grid(row=7, column=0, pady=20)

rightFrame = Frame(root)
rightFrame.place(x=300, y=65, width=860,height=600)

scrollBarX = Scrollbar(rightFrame, orient=HORIZONTAL)
scrollBarY = Scrollbar(rightFrame)

studentTable = ttk.Treeview(rightFrame,columns=('Roll', 'Name','Course', 'Mob. No.', 'Email', 'Address','Gender', 'DOB', 'DOA'),
                            xscrollcommand=scrollBarX.set, yscrollcommand=scrollBarY.set)
scrollBarX.config(command=studentTable.xview)
scrollBarY.config(command=studentTable.yview)

scrollBarX.pack(side=BOTTOM, fill=X)
scrollBarY.pack(side=RIGHT, fill=Y)
studentTable.pack(fill=BOTH, expand=1)

studentTable.heading('Roll',text='Roll')
studentTable.heading('Name',text='Name')
studentTable.heading('Course',text='Course')
studentTable.heading('Mob. No.',text='Mob. No.')
studentTable.heading('Email',text='Email')
studentTable.heading('Address',text='Address')
studentTable.heading('Gender',text='Gender')
studentTable.heading('DOB',text='DOB')
studentTable.heading('DOA',text='DOA')

studentTable.config(show='headings')


root.mainloop()